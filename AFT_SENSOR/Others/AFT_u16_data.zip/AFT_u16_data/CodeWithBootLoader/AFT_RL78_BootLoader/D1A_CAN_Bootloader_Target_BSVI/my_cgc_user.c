
#include "my_macrodriver.h"
#include "my_cgc.h"
#include "my_userdefine.h"
//----------------------------------------------------------------------------------------------------------------
void MY_CGC_Get_ResetSource(void)
{
//Must Comment here 
 //   uint8_t reset_flag = RESF;
}
//----------------------------------------------------------------------------------------------------------------
