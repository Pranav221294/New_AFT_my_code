
#ifndef CGC_H
#define CGC_H

/*
    Clock operation mode control register (CMC)
*/
/* High-speed system clock pin operation mode (EXCLK, OSCSEL) */
#define _C0_CGC_HISYS_PIN           (0xC0U)
#define _00_CGC_HISYS_PORT          (0x00U) /* X1, X2 as I/O port */
#define _40_CGC_HISYS_OSC           (0x40U) /* X1, X2 as crystal/ceramic resonator connection */
#define _80_CGC_HISYS_PORT1         (0x80U) /* X1, X2 as I/O port */
#define _C0_CGC_HISYS_EXT           (0xC0U) /* X1 as I/O port, X2 as external clock input */
/* Control of X1 high-speed system clock oscillation frequency (AMPH) */
#define _00_CGC_SYSOSC_DEFAULT      (0x00U)
#define _00_CGC_SYSOSC_UNDER10M     (0x00U) /* fX <= 10MHz */
#define _01_CGC_SYSOSC_OVER10M      (0x01U) /* fX > 10MHz */

/*
    Clock operation status control register (CSC)
*/
/* Control of high-speed system clock operation (MSTOP) */
#define _00_CGC_HISYS_OPER          (0x00U) /* X1 oscillator/external clock operating */
#define _80_CGC_HISYS_STOP          (0x80U) /* X1 oscillator/external clock stopped */
/* High-speed OCO operation (HIOSTOP) */
#define _00_CGC_HIO_OPER            (0x00U) /* high-speed OCO operating */
#define _01_CGC_HIO_STOP            (0x01U) /* high-speed OCO stopped */

/*
    Oscillation stabilization time counter status register (OSTC)
*/
/* Oscillation stabilization time status (MOST18 - MOST8) */
#define _00_CGC_OSCSTAB_STA0        (0x00U) /* < 2^8/fX */
#define _80_CGC_OSCSTAB_STA8        (0x80U) /* 2^8/fX */
#define _C0_CGC_OSCSTAB_STA9        (0xC0U) /* 2^9/fX */
#define _E0_CGC_OSCSTAB_STA10       (0xE0U) /* 2^10/fX */
#define _F0_CGC_OSCSTAB_STA11       (0xF0U) /* 2^11/fX */
#define _F8_CGC_OSCSTAB_STA13       (0xF8U) /* 2^13/fX */
#define _FC_CGC_OSCSTAB_STA15       (0xFCU) /* 2^15/fX */
#define _FE_CGC_OSCSTAB_STA17       (0xFEU) /* 2^17/fX */
#define _FF_CGC_OSCSTAB_STA18       (0xFFU) /* 2^18/fX */

/*
    Oscillation stabilization time select register (OSTS)
*/
/* Oscillation stabilization time selection (OSTS2 - OSTS0) */
#define _00_CGC_OSCSTAB_SEL8        (0x00U) /* 2^8/fX */
#define _01_CGC_OSCSTAB_SEL9        (0x01U) /* 2^9/fX */
#define _02_CGC_OSCSTAB_SEL10       (0x02U) /* 2^10/fX */
#define _03_CGC_OSCSTAB_SEL11       (0x03U) /* 2^11/fX */
#define _04_CGC_OSCSTAB_SEL13       (0x04U) /* 2^13/fX */
#define _05_CGC_OSCSTAB_SEL15       (0x05U) /* 2^15/fX */
#define _06_CGC_OSCSTAB_SEL17       (0x06U) /* 2^17/fX */
#define _07_CGC_OSCSTAB_SEL18       (0x07U) /* 2^18/fX */

/*
    PLL control register (PLLCTL)
*/
/* Lockup wait counter setting value */
#define _00_CGC_LOCKUP_WAIT_7       (0x00U) /* 2^7/fMAIN */
#define _40_CGC_LOCKUP_WAIT_8       (0x40U) /* 2^8/fMAIN */
#define _80_CGC_LOCKUP_WAIT_9       (0x80U) /* 2^9/fMAIN */
/* PLL output clock (fPLLO) division selection (PLLDIV0) */
#define _00_CGC_PLL_DIVISION_4MHZ   (0x00U) /* when fMAIN = 4 MHz */
#define _10_CGC_PLL_DIVISION_8MHZ   (0x10U) /* when fMAIN = 8 MHz */
/* Clock mode selection (SELPLL) */
#define _00_CGC_NOSEL_PLL           (0x00U) /* clock through mode */
#define _04_CGC_SEL_PLL             (0x04U) /* PLL clock select mode */
/* Operating or stopping PLL function (PLLON) */
#define _00_CGC_PLL_STOP            (0x00U) /* PLL operating stopped */
#define _01_CGC_PLL_ENABLE          (0x01U) /* PLL operating */

/*
    PLL status register (PLLSTS)
*/
/* PLL lock state */
#define _00_CGC_PLL_UNLOCKED          (0x00U) /* Unlocked state */
#define _80_CGC_PLL_LOCKED            (0x80U) /* Locked state */

/*
    FMP clock selection division register (MDIV)
*/
/* Division of PLL clock (fMP) */
#define _00_CGC_FMP_DIV_DEFAULT     (0x00U) /* fMP (default) */
#define _01_CGC_FMP_DIV_1           (0x01U) /* fMP/2^1 */
#define _02_CGC_FMP_DIV_2           (0x02U) /* fMP/2^2 */
#define _03_CGC_FMP_DIV_3           (0x03U) /* fMP/2^3 */
#define _04_CGC_FMP_DIV_4           (0x04U) /* fMP/2^4 */
#define _05_CGC_FMP_DIV_5           (0x05U) /* fMP/2^5 */

/*
    System clock control register (CKC)
*/
/* Status of Main system clock fMAIN (MCS) */
#define _00_CGC_MAINCLK_HIO         (0x00U) /* high-speed OCO clock (fIH) */
#define _20_CGC_MAINCLK_HISYS       (0x20U) /* high-speed system clock (fMX) */
/* Selection of Main system clock fMAIN (MCM0) */
#define _00_CGC_MAINCLK_SELHIO      (0x00U) /* high-speed OCO clock (fIH) */
#define _10_CGC_MAINCLK_SELHISYS    (0x10U) /* high-speed system clock (fMX) */

/*
    Operation speed mode control register (OSMC)
*/
/* Setting in subsystem clock HALT mode (RTCLPC) */
#define _00_CGC_SUBINHALT_ON        (0x00U) /* enables supply of subsystem clock to peripheral functions */
#define _80_CGC_SUBINHALT_OFF       (0x80U) /* stops supply to peripheral functions other than RTC and interval timer */
/* RTC macro operation clock (WUTMMCK0) */
#define _00_CGC_RTC_CLK_OTHER       (0x00U) /* Other than fIL */
#define _10_CGC_RTC_CLK_FIL         (0x10U) /* use fIL clcok */

/*
    Illegal memory access detection control register (IAWCTL)
*/
/* Illegal memory access detection control (IAWEN) */
#define _00_CGC_ILLEGAL_ACCESS_OFF  (0x00U) /* disables illegal memory access detection */
#define _80_CGC_ILLEGAL_ACCESS_ON   (0x80U) /* enables illegal memory access detection */
/* RAM guard area (GRAM1, GRAM0) */
#define _00_CGC_RAM_GUARD_OFF       (0x00U) /* invalid, it is possible to write RAM */
#define _10_CGC_RAM_GUARD_AREA0     (0x10U) /* 128 bytes from RAM bottom address */
#define _20_CGC_RAM_GUARD_AREA1     (0x20U) /* 256 bytes from RAM bottom address */
#define _30_CGC_RAM_GUARD_AREA2     (0x30U) /* 512 bytes from RAM bottom address */
/* PORT register guard (GPORT) */
#define _00_CGC_PORT_GUARD_OFF      (0x00U) /* invalid, it is possible to write PORT register */
#define _04_CGC_PORT_GUARD_ON       (0x04U) /* valid, it is impossible to write PORT register, but possible for read */
/* Interrupt register guard (GINT) */   
#define _00_CGC_INT_GUARD_OFF       (0x00U) /* invalid, it is possible to write interrupt register */
#define _02_CGC_INT_GUARD_ON        (0x02U) /* valid, impossible to write interrupt register, but possible for read */
/* CSC register guard (GCSC) */
#define _00_CGC_CSC_GUARD_OFF       (0x00U) /* invalid, it is possible to write CSC register */
#define _01_CGC_CSC_GUARD_ON        (0x01U) /* valid, it is impossible to write CSC register, but possible for read */

/*
    RTC clock selection register (RTCCL)
*/
/* Operation clock source selection for RTC/interval timer (RTCCL7) */
#define _00_CGC_RTC_FMX             (0x00U) /* RTC/interval timer uses External Main clock (fMX) */
#define _80_CGC_RTC_FIH             (0x80U) /* RTC/interval timer uses Internal high speed clock (fIH) */
/* Operation selection of RTC macro and interval timer (RTCCL6,RTCCKS1 - RTCCKS0)  */
#define _00_CGC_RTC_FSUB            (0x00U) /* RTC/interval timer uses sub clock */
#define _01_CGC_RTC_FIL             (0x01U) /* RTC/interval timer uses internal low speed OSC clock */
#define _02_CGC_RTC_DIV128          (0x02U) /* RTC/interval timer uses high-speed clock / 128 */
#define _03_CGC_RTC_DIV256          (0x03U) /* RTC/interval timer uses high-speed clock / 256 */
#define _42_CGC_RTC_DIV122          (0x42U) /* RTC/interval timer uses high-speed clock / 122 */
#define _43_CGC_RTC_DIV244          (0x43U) /* RTC/interval timer uses high-speed clock / 244 */

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef enum
{
    HIOCLK, 
    SYSX1CLK, 
    SYSEXTCLK
} clock_mode_t;

//----------------------------------------------------------------------------------------------------------------
void MY_CGC_Create(void);
void MY_CGC_Get_ResetSource(void);
//----------------------------------------------------------------------------------------------------------------
#endif
