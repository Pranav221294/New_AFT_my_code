after changing application .mot file to .bin file, rename the .bin file as Ultra24V.bin
then upload through app.